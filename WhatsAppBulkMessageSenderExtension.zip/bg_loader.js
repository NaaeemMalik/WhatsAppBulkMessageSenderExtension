try {
    importScripts('bg.js', 'log.js');
} catch (e) {
    console.error(e);
}